from selenium import webdriver
from bs4 import BeautifulSoup
import sqlite3
from celery import Celery
from datetime import datetime

# Initialize Celery app with Redis broker URL
app = Celery('scraper', broker='redis://localhost:6379/0')


@app.task
def scrape_and_store():
    # 1. Launch Selenium WebDriver (Chrome)
    options = webdriver.ChromeOptions()
    options.add_argument('--headless')  # Run browser in headless mode
    driver = webdriver.Chrome(options=options)

    try:
        driver.get('https://quotes.toscrape.com/js/')
        soup = BeautifulSoup(driver.page_source, 'html.parser')

        # 2. Extract quotes text by CSS selector
        quotes = soup.select('.quote span.text')
        data = [(datetime.now(), quote.text) for quote in quotes]

        # 3. Save to SQLite database
        conn = sqlite3.connect('scraped_data.db')
        c = conn.cursor()
        c.execute('CREATE TABLE IF NOT EXISTS quotes (timestamp DATETIME, quote TEXT)')
        c.executemany('INSERT INTO quotes VALUES (?, ?)', data)
        conn.commit()
        conn.close()

        print(f"Scraped and stored {len(data)} quotes at {datetime.now()}")

    finally:
        driver.quit()
