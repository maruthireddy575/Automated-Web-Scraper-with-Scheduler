# Automated Web Scraper with Scheduler

This project scrapes dynamic websites periodically using Selenium and BeautifulSoup, schedules scraping with Celery, and stores data in SQLite.

## Setup

1. Install Redis and start the server.
2. Install Python dependencies:
