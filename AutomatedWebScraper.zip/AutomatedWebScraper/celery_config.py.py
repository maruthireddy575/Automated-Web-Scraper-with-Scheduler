import redis
from celery import Celery
from celery.schedules import crontab

app = Celery('scraper', broker='redis://localhost:6379/0')

app.conf.beat_schedule = {
    'scrape-every-1-minute': {
        'task': 'scraper.scrape_and_store',
        'schedule': crontab(minute='*/1'),  # Every 1 min for demo; change as needed
    },
}

app.conf.timezone = 'UTC'
